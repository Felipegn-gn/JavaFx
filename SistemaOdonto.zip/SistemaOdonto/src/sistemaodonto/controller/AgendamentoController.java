/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package sistemaodonto.controller;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;      
import sistemaodonto.model.Cliente;

public class AgendamentoController implements Initializable {

    @FXML
    private TextField textField_Nome;
    @FXML
    private ComboBox<String> combo_NomeProfissional;
    @FXML
    private DatePicker datePicker_DatasDisponiveis;
    @FXML
    private ComboBox<String> combo_horariosDisponiveis;
    @FXML
    private TextField textField_CPF;
    @FXML
    private TextField textField_Telefone;
    @FXML
    private DatePicker datePicker_Nascimento;
    @FXML
    private  Button button_Excluir;
    
    @FXML
    private  Button button_Buscar;
    @FXML
    private  Button button_Limpar;
    
    @FXML
    private  Button button_Marcar;
    @FXML
    private  Button button_Cancelar;

    
    

    @Override
    public void initialize(URL location, ResourceBundle resources) {
      
        button_Marcar.setDisable(true);
        button_Cancelar.setDisable(true);
        button_Excluir.setDisable(true);

        // Verifica se os campos de texto estão preenchidos para habilitar o botão Marcar
        textField_Nome.textProperty().addListener((obs, oldText, newText) -> verificarCampos());
        textField_CPF.textProperty().addListener((obs, oldText, newText) -> verificarCampos());
        
    }
    
    @FXML
    private void cancelarAgendamento() {
        // Limpa os campos de entrada
        limparCampos();
        // Garante que o botão Adicionar esteja habilitado, se necessário
        verificarCampos(); // Habilita o botão de adicionar, se os campos necessários estiverem preenchidos
    }

    @FXML
    private void marcarAgendamento() {
        String nome = textField_Nome.getText();
        String cpf = textField_CPF.getText();
        String telefone = textField_Telefone.getText();
        String dataNascimento = datePicker_Nascimento.getValue() != null ? datePicker_Nascimento.getValue().toString() : "";
        String dataDisponiveis = datePicker_DatasDisponiveis.getValue() != null ? datePicker_DatasDisponiveis.getValue().toString() : "";

    }

    @FXML
    private void excluirCliente() {
        
    }
    @FXML
    private void adicionarAgendamento() {
        // Habilitar campos para entrada de dados
        habilitarCampos();

        // Limpar campos para um novo cliente
        limparCampos();

        // Habilitar os botões Cancelar
        button_Cancelar.setDisable(false);
    }
    private void habilitarCampos() {
        textField_Nome.setDisable(false);
        textField_CPF.setDisable(false);
        textField_Telefone.setDisable(false);
        datePicker_Nascimento.setDisable(false);
    }
    private void desabilitarCampos() {
        textField_Nome.setDisable(true);
        textField_CPF.setDisable(true);
        textField_Telefone.setDisable(true);
        datePicker_Nascimento.setDisable(true);
    }
    
    private void verificarCampos() {

    }

    private boolean camposPreenchidos() {
        return !textField_Nome.getText().isEmpty() &&
               !textField_CPF.getText().isEmpty();
    }

    private void preencherCampos(Cliente cliente) {
        textField_Nome.setText(cliente.getNome());
        textField_CPF.setText(cliente.getCpf());
        textField_Telefone.setText(cliente.getTelefone());
        datePicker_Nascimento.setValue(cliente.getDataNascimento() != null ? LocalDate.parse(cliente.getDataNascimento()) : null);
    }

    private void limparCampos() {
        textField_Nome.clear();
        textField_CPF.clear();
        textField_Telefone.clear();
        datePicker_Nascimento.setValue(null);

        button_Marcar.setDisable(true);
        button_Excluir.setDisable(true);

    }
}
