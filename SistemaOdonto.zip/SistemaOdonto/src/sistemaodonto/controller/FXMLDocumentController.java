/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package sistemaodonto.controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

/**
 *
 * @author Luan
 */
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;      
import sistemaodonto.model.Cliente;

public class FXMLDocumentController implements Initializable {

    @FXML
    private TextField textField_Id;
    @FXML
    private TextField textField_Nome;
    @FXML
    private TextField textField_CPF;
    @FXML
    private TextField textField_Telefone;
    @FXML
    private TextField textField_Endereco;
    @FXML
    private TextField textField_Numero;
    @FXML
    private TextField textField_Cidade;
    @FXML
    private TextField textField_UF;
    @FXML
    private TextField textField_CEP;
    @FXML
    private DatePicker datePicker_Nascimento;
    @FXML
    private ComboBox<String> combo_sexo;

     @FXML
    private  Button button_Atualizar;
     
    @FXML
    private  Button button_Excluir;
    
    @FXML
    private  Button button_Salvar;
    
    @FXML
    private  Button button_Cancelar;

    
    

    @Override
    public void initialize(URL location, ResourceBundle resources) {
      
        button_Atualizar.setDisable(true);
        button_Salvar.setDisable(true);
        button_Cancelar.setDisable(true);
        button_Excluir.setDisable(true);
        combo_sexo.getItems().addAll("Masculino", "Feminino");

        // Verifica se os campos de texto estão preenchidos para habilitar o botão Adicionar
        textField_Nome.textProperty().addListener((obs, oldText, newText) -> verificarCampos());
        textField_CPF.textProperty().addListener((obs, oldText, newText) -> verificarCampos());
        textField_Telefone.textProperty().addListener((obs, oldText, newText) -> verificarCampos());
        datePicker_Nascimento.valueProperty().addListener((obs, oldText, newText) -> verificarCampos());
       
    }
    
    @FXML
    private void cancelarCliente() {
        // Limpa os campos de entrada
        limparCampos();
        // Garante que o botão Adicionar esteja habilitado, se necessário
        verificarCampos(); // Habilita o botão de adicionar, se os campos necessários estiverem preenchidos
    }

    @FXML
    private void salvarCliente() {
        String id = textField_Id.getText();
        String nome = textField_Nome.getText();
        String cpf = textField_CPF.getText();
        String telefone = textField_Telefone.getText();
        String endereco = textField_Endereco.getText();
        String numero = textField_Numero.getText();
        String cidade = textField_Cidade.getText();
        String uf = textField_UF.getText();
        String cep = textField_CEP.getText();
        String dataNascimento = datePicker_Nascimento.getValue() != null ? datePicker_Nascimento.getValue().toString() : "";

    }

    @FXML
    private void atualizarCliente() {
        
        
    }
    
    @FXML
    private void cancelarPrograma() {
        
        Platform.exit();
    }

    @FXML
    private void excluirCliente() {
        
    }
    
    @FXML
    private void adicionarCliente() {
        // Habilitar campos para entrada de dados
        habilitarCampos();

        // Limpar campos para um novo cliente
        limparCampos();

        // Habilitar os botões Cancelar
        button_Cancelar.setDisable(false);
    }
    private void habilitarCampos() {
        textField_Nome.setDisable(false);
        textField_CPF.setDisable(false);
        textField_Telefone.setDisable(false);
        textField_Endereco.setDisable(false);
        textField_Numero.setDisable(false);
        textField_Cidade.setDisable(false);
        textField_UF.setDisable(false);
        textField_CEP.setDisable(false);
        datePicker_Nascimento.setDisable(false);
    }
    private void desabilitarCampos() {
        textField_Nome.setDisable(true);
        textField_CPF.setDisable(true);
        textField_Telefone.setDisable(true);
        textField_Endereco.setDisable(true);
        textField_Numero.setDisable(true);
        textField_Cidade.setDisable(true);
        textField_UF.setDisable(true);
        textField_CEP.setDisable(true);
        datePicker_Nascimento.setDisable(true);
    }
    
    private void verificarCampos() {
        button_Salvar.setDisable(!camposPreenchidos());
        button_Cancelar.setDisable(!camposPreenchidos());
    }

    private boolean camposPreenchidos() {
        return !textField_Nome.getText().isEmpty() &&
               !textField_CPF.getText().isEmpty() &&
               !textField_Telefone.getText().isEmpty() &&
               datePicker_Nascimento.getValue() != null;
    }

    private void preencherCampos(Cliente cliente) {
        textField_Id.setText(cliente.getId());
        textField_Nome.setText(cliente.getNome());
        textField_CPF.setText(cliente.getCpf());
        textField_Telefone.setText(cliente.getTelefone());
        textField_Endereco.setText(cliente.getEndereco());
        textField_Numero.setText(cliente.getNumero());
        textField_Cidade.setText(cliente.getCidade());
        textField_UF.setText(cliente.getUf());
        textField_CEP.setText(cliente.getCep());
        datePicker_Nascimento.setValue(cliente.getDataNascimento() != null ? LocalDate.parse(cliente.getDataNascimento()) : null);
    }

    private void limparCampos() {
        textField_Id.clear();
        textField_Nome.clear();
        textField_CPF.clear();
        textField_Telefone.clear();
        textField_Endereco.clear();
        textField_Numero.clear();
        textField_Cidade.clear();
        textField_UF.clear();
        textField_CEP.clear();
        datePicker_Nascimento.setValue(null);

        button_Atualizar.setDisable(true);
        button_Excluir.setDisable(true);

    }
}
