/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package sistemaodonto.controller;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import sistemaodonto.model.Cliente;

public class AgendamentoController implements Initializable {

    @FXML
    private TextField textField_Nome;
    @FXML
    private ComboBox<String> combo_NomeProfissional;
    @FXML
    private DatePicker datePicker_DatasDisponiveis;
    @FXML
    private ComboBox<String> combo_horariosDisponiveis;
    @FXML
    private TextField textField_CPF;
    @FXML
    private TextField textField_Telefone;
    @FXML
    private TextField textField_DataNascimento;
    @FXML
    private Button button_Excluir;

    @FXML
    private Button button_Buscar;
    @FXML
    private Button button_Limpar;

    @FXML
    private Button button_Marcar;
    @FXML
    private Button button_Cancelar;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        button_Marcar.setDisable(true);
        button_Cancelar.setDisable(false);
        combo_NomeProfissional.getItems().addAll("Dr. Paulo Alex", "Dra. Joaquina Pereira");
        combo_NomeProfissional.setOnAction(event -> atualizarHorarios());

        // Verifica se os campos de texto estão preenchidos para habilitar o botão Marcar
        textField_Nome.textProperty().addListener((obs, oldText, newText) -> verificarCampos());
        textField_CPF.textProperty().addListener((obs, oldText, newText) -> verificarCampos());
        textField_DataNascimento.textProperty().addListener((obs, oldText, newText) -> verificarCampos());
        textField_Telefone.textProperty().addListener((obs, oldText, newText) -> verificarCampos());

    }

    @FXML
    private void cancelarPrograma() {

        Platform.exit();
    }

    @FXML
    private void marcarAgendamento() {
        String nome = textField_Nome.getText();
        String cpf = textField_CPF.getText();
        String telefone = textField_Telefone.getText();
        String dataNascimento = textField_DataNascimento.getText();
        String dataDisponiveis = datePicker_DatasDisponiveis.getValue() != null ? datePicker_DatasDisponiveis.getValue().toString() : "";

    }
    
    private void atualizarHorarios() {
    String profissional = combo_NomeProfissional.getValue();
    combo_horariosDisponiveis.getItems().clear();

    if (profissional == null) return;

    switch (profissional) {
        case "Dr. Paulo Alex":
            combo_horariosDisponiveis.getItems().addAll(
                "08:00", "09:00", "10:00", "14:00", "15:00"
            );
            break;
        case "Dra. Joaquina Pereira":
            combo_horariosDisponiveis.getItems().addAll(
                "09:30", "11:00", "13:00", "16:00"
            );
            break;
        default:
            break;
    }
}

    @FXML
    private void limparCliente() {
        textField_CPF.clear();
        textField_Nome.clear();
        textField_DataNascimento.clear();
        textField_Telefone.clear();
    }

    private void habilitarCampos() {
        textField_Nome.setDisable(false);
        textField_CPF.setDisable(false);
        textField_Telefone.setDisable(false);
        textField_DataNascimento.setDisable(false);
    }

    private void desabilitarCampos() {
        textField_Nome.setDisable(true);
        textField_CPF.setDisable(true);
        textField_Telefone.setDisable(true);
        textField_DataNascimento.setDisable(true);
    }

    private void verificarCampos() {
        button_Marcar.setDisable(!camposPreenchidos());
    }

    private boolean camposPreenchidos() {
        return !textField_Nome.getText().isEmpty()
                && !textField_CPF.getText().isEmpty()
                && !textField_DataNascimento.getText().isEmpty()
                && !textField_Telefone.getText().isEmpty();
    }

    private void preencherCampos(Cliente cliente) {
        textField_Nome.setText(cliente.getNome());
        textField_CPF.setText(cliente.getCpf());
        textField_Telefone.setText(cliente.getTelefone());
        textField_DataNascimento.setText(cliente.getDataNascimento());
    }

    private void limparCampos() {
        textField_Nome.clear();
        textField_CPF.clear();
        textField_Telefone.clear();
        textField_DataNascimento.clear();

        button_Marcar.setDisable(true);
        button_Excluir.setDisable(true);

    }
}
