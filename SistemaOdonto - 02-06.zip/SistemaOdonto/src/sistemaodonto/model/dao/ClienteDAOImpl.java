/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemaodonto.model.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import sistemaodonto.model.Cliente;

/**
 *
 * @author Laboratorio
 */
public class ClienteDAOImpl implements ClienteDAO {
    
    public List<Cliente> clientes = new ArrayList<>();

    @Override
    public void salvar(Cliente cliente) {
        clientes.add(cliente);
    }

    @Override
    public void atualizar(Cliente cliente) {
        Optional<Cliente> clienteExistente = clientes.stream()
                .filter(c -> c.getId().equals(cliente.getId()))
                .findFirst();

        clienteExistente.ifPresent(c -> {
            c.setNome(cliente.getNome());
            c.setCpf(cliente.getCpf());
            c.setTelefone(cliente.getTelefone());
            c.setEndereco(cliente.getEndereco());
            c.setNumero(cliente.getNumero());
            c.setCidade(cliente.getCidade());
            c.setUf(cliente.getUf());
            c.setCep(cliente.getCep());
            c.setDataNascimento(cliente.getDataNascimento());
            c.setSexo(cliente.getSexo());
        });
    }

    @Override
    public void deletar(String id) {
        clientes.removeIf(cliente -> cliente.getId().equals(id));
    }

    @Override
    public Cliente buscarPorCpf(String cpf) {
        return clientes.stream()
                .filter(cliente -> cliente.getCpf().equals(cpf))
                .findFirst()
                .orElse(null);
    }

    @Override
    public List<Cliente> listarTodos() {
        return clientes;
    }
    
}
