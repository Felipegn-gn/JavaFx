/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML.java to edit this template
 */
package sistemaodonto.main;

import java.io.IOException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author falea
 */
public class SistemaOdonto extends Application {

    @Override
    public void start(Stage primaryStage) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/sistemaodonto/View/FXMLDocument.fxml"));
            if (loader.getLocation() == null) {
                System.err.println("Arquivo FXML não encontrado.");
            }
            Parent root = loader.load();
            Scene scene = new Scene(root);
            primaryStage.setTitle("Cadastro de Cliente");
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace(); // Mostra o erro de I/O
        } catch (Exception e) {
            e.printStackTrace(); // Mostra outros erros
        }

    }

    public static void main(String[] args) {
        // Inicializa a aplicação JavaFX
        launch(args);
    }
}
