/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package sistemaodonto.controller;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import sistemaodonto.model.Cliente;
import sistemaodonto.model.dao.ClienteDAO;
import sistemaodonto.model.dao.ClienteDAOImpl;

public class AgendamentoController implements Initializable {

    @FXML
    private TextField textField_Nome;
    @FXML
    private ComboBox<String> combo_NomeProfissional;
    @FXML
    private DatePicker datePicker_DatasDisponiveis;
    @FXML
    private ComboBox<String> combo_horariosDisponiveis;
    @FXML
    private TextField textField_CPF;
    @FXML
    private TextField textField_Telefone;
    @FXML
    private TextField textField_DataNascimento;
    @FXML
    private Button button_Excluir;

    @FXML
    private Button button_Limpar;

    @FXML
    private Button button_Marcar;
    @FXML
    private Button button_Cancelar;
    
    private final ClienteDAO clienteDAO = new ClienteDAOImpl();
    
    private Cliente clienteCarregadoParaAgendamento;
    private Cliente clientePreSelecionado;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        textField_Nome.setEditable(false);
        textField_DataNascimento.setEditable(false);
        textField_Telefone.setEditable(false);

        button_Marcar.setDisable(true);
        button_Cancelar.setDisable(false);
        combo_NomeProfissional.getItems().addAll("Dr. Paulo Alex", "Dra. Joaquina Pereira");
        combo_NomeProfissional.setOnAction(event -> atualizarHorarios());

        // Verifica se os campos de texto estão preenchidos para habilitar o botão Marcar
        textField_Nome.textProperty().addListener((obs, oldText, newText) -> verificarCampos());
        textField_CPF.textProperty().addListener((obs, oldText, newText) -> verificarCampos());
        textField_DataNascimento.textProperty().addListener((obs, oldText, newText) -> verificarCampos());
        textField_Telefone.textProperty().addListener((obs, oldText, newText) -> verificarCampos());
        
        button_Limpar.disableProperty().bind(textField_CPF.textProperty().isEmpty());

    }

    @FXML
    private void cancelarPrograma() {

        Platform.exit();
    }

    @FXML
    private void marcarAgendamento() {
        String nome = textField_Nome.getText();
        String cpf = textField_CPF.getText();
        String telefone = textField_Telefone.getText();
        String dataNascimento = textField_DataNascimento.getText();
        String dataDisponiveis = datePicker_DatasDisponiveis.getValue() != null ? datePicker_DatasDisponiveis.getValue().toString() : "";
        String nomeProfissional = combo_NomeProfissional.getValue();
        String horarioSelecionado = combo_horariosDisponiveis.getValue();
        
    }
    
    public void carregarDadosCliente(Cliente cliente) {
    this.clientePreSelecionado = cliente;

    if (this.clientePreSelecionado != null) {
        // Preenche o campo CPF
        textField_CPF.setText(this.clientePreSelecionado.getCpf());

        // Preenche os campos de exibição do cliente diretamente
        textField_Nome.setText(this.clientePreSelecionado.getNome());
        textField_DataNascimento.setText(this.clientePreSelecionado.getDataNascimento()); // Assumindo que é String
        textField_Telefone.setText(this.clientePreSelecionado.getTelefone());
        
        // Armazena o cliente carregado para uso no agendamento
        this.clienteCarregadoParaAgendamento = this.clientePreSelecionado; 

        // Habilita os campos para marcar o agendamento e o botão
        habilitarCampos(true);
        button_Marcar.setDisable(false);
        datePicker_DatasDisponiveis.requestFocus(); // Foca no campo de data do agendamento
        
        // Opcional: Você pode desabilitar o campo CPF e o botão buscar se um cliente já foi carregado
        // textField_CPF_Agendamento.setEditable(false);
        // button_Buscar_Agendamento.setDisable(true);
    }
}
    
    private void atualizarHorarios() {
    String profissional = combo_NomeProfissional.getValue();
    combo_horariosDisponiveis.getItems().clear();

    if (profissional == null) return;

    switch (profissional) {
        case "Dr. Paulo Alex":
            combo_horariosDisponiveis.getItems().addAll(
                "08:00", "09:00", "10:00", "14:00", "15:00"
            );
            break;
        case "Dra. Joaquina Pereira":
            combo_horariosDisponiveis.getItems().addAll(
                "09:30", "11:00", "13:00", "16:00"
            );
            break;
        default:
            break;
    }
}

    @FXML
    private void limparCliente() {
        textField_CPF.clear();
        textField_Nome.clear();
        textField_DataNascimento.clear();
        textField_Telefone.clear();
    }

    private void habilitarCampos(boolean par) {
        textField_Nome.setDisable(false);
        textField_CPF.setDisable(false);
        textField_Telefone.setDisable(false);
        textField_DataNascimento.setDisable(false);
    }

    private void desabilitarCampos() {
        textField_Nome.setDisable(true);
        textField_CPF.setDisable(true);
        textField_Telefone.setDisable(true);
        textField_DataNascimento.setDisable(true);
    }

    private void verificarCampos() {
        button_Marcar.setDisable(!camposPreenchidos());
    }

    private boolean camposPreenchidos() {
        return !textField_Nome.getText().isEmpty()
                && !textField_CPF.getText().isEmpty()
                && !textField_DataNascimento.getText().isEmpty()
                && !textField_Telefone.getText().isEmpty();
    }

    private void preencherCampos(Cliente cliente) {
        textField_Nome.setText(cliente.getNome());
        textField_CPF.setText(cliente.getCpf());
        textField_Telefone.setText(cliente.getTelefone());
        textField_DataNascimento.setText(cliente.getDataNascimento());
    }

    private void limparCampos() {
        textField_Nome.clear();
        textField_CPF.clear();
        textField_Telefone.clear();
        textField_DataNascimento.clear();

        button_Marcar.setDisable(true);
        button_Excluir.setDisable(true);

    }
}
