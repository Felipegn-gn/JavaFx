/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package sistemaodonto.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import sistemaodonto.model.Cliente;
import sistemaodonto.model.dao.ClienteDAO;
import sistemaodonto.model.dao.ClienteDAOImpl;
import javafx.scene.control.Alert;

public class AgendamentoController implements Initializable {

    @FXML
    private TextField textField_Nome;
    @FXML
    private ComboBox<String> combo_NomeProfissional;
    @FXML
    private DatePicker datePicker_DatasDisponiveis;
    @FXML
    private ComboBox<String> combo_horariosDisponiveis;
    @FXML
    private TextField textField_CPF;
    @FXML
    private TextField textField_Telefone;
    @FXML
    private TextField textField_DataNascimento;
    @FXML
    private Button button_Excluir;

    @FXML
    private Button button_Limpar;

    @FXML
    private Button button_Marcar;
    @FXML
    private Button button_Cancelar;
    @FXML
    private Button button_Voltar;
    
    
    private final ClienteDAO clienteDAO = new ClienteDAOImpl();
    
    private Cliente clienteCarregadoParaAgendamento;
    private Cliente clientePreSelecionado;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        textField_Nome.setEditable(false);
        textField_DataNascimento.setEditable(false);
        textField_Telefone.setEditable(false);

        button_Marcar.setDisable(true);
        button_Cancelar.setDisable(false);
        
        combo_NomeProfissional.getItems().addAll("Dr. Paulo Alex", "Dra. Joaquina Pereira");
        combo_NomeProfissional.setOnAction(event -> atualizarHorarios());

        // Verifica se os campos de texto estão preenchidos para habilitar o botão Marcar
        textField_CPF.textProperty().addListener((obs, oldText, newText) -> verificarCampos());
        datePicker_DatasDisponiveis.valueProperty().addListener((obs, oldVal, newVal) -> verificarCampos());
        combo_NomeProfissional.valueProperty().addListener((obs, oldVal, newVal) -> verificarCampos());
        combo_horariosDisponiveis.valueProperty().addListener((obs, oldVal, newVal) -> verificarCampos());
        
        button_Limpar.disableProperty().bind(textField_CPF.textProperty().isEmpty());

    }
@FXML
private void voltarCadastro(ActionEvent event) {
    try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/sistemaodonto/View/FXMLDocument.fxml"));
        Parent root = loader.load();
       
        FXMLDocumentController fxmldocumentController = loader.getController(); 

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Cadastro");
        stage.show(); 

    } catch (IOException e) {
        System.err.println("Erro ao carregar a tela de cadastro: " + e.getMessage());
        e.printStackTrace();

    }
}


    @FXML
    private void cancelarPrograma() {

        Platform.exit();
    }

    @FXML
    private void marcarAgendamento() {
        String nome = textField_Nome.getText();
        String cpf = textField_CPF.getText();
        String telefone = textField_Telefone.getText();
        String dataNascimento = textField_DataNascimento.getText();
        String dataDisponiveis = datePicker_DatasDisponiveis.getValue() != null ? datePicker_DatasDisponiveis.getValue().toString() : "";
        String nomeProfissional = combo_NomeProfissional.getValue();
        String horarioSelecionado = combo_horariosDisponiveis.getValue();
        mostrarAlerta("Sucesso", "Consulta Agendada!", Alert.AlertType.INFORMATION);
        limparCampos();
        
    }
    
    public void carregarDadosCliente(Cliente cliente) {
    this.clientePreSelecionado = cliente;

    if (this.clientePreSelecionado != null) {
        // Preenche o campo CPF
        textField_CPF.setText(this.clientePreSelecionado.getCpf());

        // Preenche os campos de exibição do cliente diretamente
        textField_Nome.setText(this.clientePreSelecionado.getNome());
        textField_DataNascimento.setText(this.clientePreSelecionado.getDataNascimento()); // Assumindo que é String
        textField_Telefone.setText(this.clientePreSelecionado.getTelefone());
        
        // Armazena o cliente carregado para uso no agendamento
        this.clienteCarregadoParaAgendamento = this.clientePreSelecionado; 

        // Habilita os campos para marcar o agendamento e o botão
        habilitarCampos(true);
        button_Marcar.setDisable(false);
        datePicker_DatasDisponiveis.requestFocus(); // Foca no campo de data do agendamento

    }
}
    
    private void atualizarHorarios() {
    String profissional = combo_NomeProfissional.getValue();
    combo_horariosDisponiveis.getItems().clear();

    if (profissional == null) return;

    switch (profissional) {
        case "Dr. Paulo Alex":
            combo_horariosDisponiveis.getItems().addAll(
                "08:00", "09:00", "10:00", "14:00", "15:00"
            );
            break;
        case "Dra. Joaquina Pereira":
            combo_horariosDisponiveis.getItems().addAll(
                "09:30", "11:00", "13:00", "16:00"
            );
            break;
        default:
            break;
    }
}

    @FXML
    private void limparCliente() {
        textField_CPF.clear();
        textField_Nome.clear();
        textField_DataNascimento.clear();
        textField_Telefone.clear();
    }

    private void habilitarCampos(boolean par) {
        textField_Nome.setDisable(false);
        textField_CPF.setDisable(false);
        textField_Telefone.setDisable(false);
        textField_DataNascimento.setDisable(false);
    }

    private void desabilitarCampos() {
        textField_Nome.setDisable(true);
        textField_CPF.setDisable(true);
        textField_Telefone.setDisable(true);
        textField_DataNascimento.setDisable(true);
    }

    private void verificarCampos() {
        button_Marcar.setDisable(!camposPreenchidos());
    }

    private boolean camposPreenchidos() {
        return !textField_Nome.getText().isEmpty()
                && !textField_CPF.getText().isEmpty()
                && !textField_DataNascimento.getText().isEmpty()
                && !textField_Telefone.getText().isEmpty()
                && datePicker_DatasDisponiveis.getValue() != null
                && combo_NomeProfissional.getValue() != null
                && combo_horariosDisponiveis.getValue() != null;
    }

    private void preencherCampos(Cliente cliente) {
        textField_Nome.setText(cliente.getNome());
        textField_CPF.setText(cliente.getCpf());
        textField_Telefone.setText(cliente.getTelefone());
        textField_DataNascimento.setText(cliente.getDataNascimento());
    }

    private void limparCampos() {
        textField_Nome.clear();
        textField_CPF.clear();
        textField_Telefone.clear();
        textField_DataNascimento.clear();
        datePicker_DatasDisponiveis.setValue(null);
        combo_NomeProfissional.getItems().clear();
        combo_horariosDisponiveis.getItems().clear();
        
        button_Marcar.setDisable(true);
        button_Excluir.setDisable(true);

    }
       public void mostrarAlerta(String titulo, String mensagem, Alert.AlertType tipoAlerta) {
        Alert alerta = new Alert(tipoAlerta);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensagem);
        alerta.showAndWait();
    }
}


