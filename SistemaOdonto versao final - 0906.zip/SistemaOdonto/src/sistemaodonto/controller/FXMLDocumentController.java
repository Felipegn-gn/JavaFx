/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package sistemaodonto.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

/**
 *
 * @author Luan
 */
import java.net.URL;
import java.time.LocalDate;
import java.util.Objects;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import sistemaodonto.model.Cliente;
import sistemaodonto.model.dao.ClienteDAO;
import sistemaodonto.model.dao.ClienteDAOImpl;

public class FXMLDocumentController implements Initializable {

    @FXML
    private TextField textField_Id;
    @FXML
    private TextField textField_Nome;
    @FXML
    private TextField textField_CPF;
    @FXML
    private TextField textField_Telefone;
    @FXML
    private TextField textField_Endereco;
    @FXML
    private TextField textField_Numero;
    @FXML
    private TextField textField_Cidade;
    @FXML
    private TextField textField_UF;
    @FXML
    private TextField textField_CEP;
    @FXML
    private DatePicker datePicker_Nascimento;
    @FXML
    private ComboBox<String> combo_sexo;

    @FXML
    private Button button_Atualizar;

    @FXML
    private Button button_Excluir;

    @FXML
    private Button button_Salvar;

    @FXML
    private Button button_Cancelar;

    @FXML
    private TableView<Cliente> tableView_Clientes;
    @FXML
    private TableColumn<Cliente, String> tableColumn_Nome;
    @FXML
    private TableColumn<Cliente, String> tableColumn_CPF;
    @FXML
    private TableColumn<Cliente, String> tableColumn_Telefone;
    @FXML
    private TableColumn<Cliente, String> tableColumn_DtNascimento;

    private ObservableList<Cliente> listaClientes;
    private final ClienteDAO clienteDAO = new ClienteDAOImpl(); // Instância da DAO

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        listaClientes = FXCollections.observableArrayList();
        configurarColunas();
        tableView_Clientes.setItems(listaClientes);

        button_Atualizar.setDisable(true);
        button_Salvar.setDisable(true);
        button_Cancelar.setDisable(true);
        button_Excluir.setDisable(true);
        combo_sexo.getItems().addAll("Masculino", "Feminino");

        // Verifica se os campos de texto estão preenchidos para habilitar o botão Salvar e Cancelar
        textField_Nome.textProperty().addListener((obs, oldText, newText) -> verificarCampos());
        textField_CPF.textProperty().addListener((obs, oldText, newText) -> verificarCampos());
        textField_Telefone.textProperty().addListener((obs, oldText, newText) -> verificarCampos());
        datePicker_Nascimento.valueProperty().addListener((obs, oldText, newText) -> verificarCampos());

        tableView_Clientes.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                button_Atualizar.setDisable(false);
                button_Excluir.setDisable(false);
                preencherCampos(newSelection);
            } else {
                button_Atualizar.setDisable(true);
                button_Excluir.setDisable(true);
            }
        });

        carregarClientesNaTabela();

    }

    private void configurarColunas() {
        tableColumn_Nome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        tableColumn_CPF.setCellValueFactory(new PropertyValueFactory<>("cpf"));
        tableColumn_Telefone.setCellValueFactory(new PropertyValueFactory<>("telefone"));
    }

    @FXML
    private void cancelarCliente() {
        // Limpa os campos de entrada
        limparCampos();

        verificarCampos();
    }

    @FXML
    private void salvarCliente() {
        String id = textField_Id.getText();
        String nome = textField_Nome.getText();
        String cpf = textField_CPF.getText();
        String telefone = textField_Telefone.getText();
        String endereco = textField_Endereco.getText();
        String numero = textField_Numero.getText();
        String cidade = textField_Cidade.getText();
        String uf = textField_UF.getText();
        String cep = textField_CEP.getText();
        String dataNascimento = datePicker_Nascimento.getValue() != null ? datePicker_Nascimento.getValue().toString() : "";
        String sexo = combo_sexo.getValue();

        Cliente novoCliente = new Cliente(id, nome, cpf, telefone, endereco, numero, cidade, uf, cep, dataNascimento, sexo);
        clienteDAO.salvar(novoCliente); // Adiciona o cliente na base de dados
        listaClientes.add(novoCliente); // Atualiza a lista em memória
        tableView_Clientes.refresh();
        limparCampos();

        boolean sucessoAoSalvar = false;
        try {
            // Se a linha acima executar sem erros, consideramos sucesso:
            sucessoAoSalvar = true;

            System.out.println("Cliente salvo com sucesso no backend/banco."); // Log para debug

        } catch (Exception e) {
            // Se ocorrer um erro durante o salvamento
            e.printStackTrace(); // Imprime o stack trace do erro no console
            mostrarAlerta("Erro ao Salvar", "Ocorreu um erro ao tentar salvar o cliente: " + e.getMessage(), AlertType.ERROR);
            return; // Interrompe a execução aqui
        }

        if (sucessoAoSalvar) {
            // Mostra a mensagem de sucesso
            mostrarAlerta("Sucesso", "Cliente salvo com sucesso!", AlertType.INFORMATION);

        }

    }

    @FXML
    private void atualizarCliente() {

        Cliente clienteSelecionado = tableView_Clientes.getSelectionModel().getSelectedItem();
        if (clienteSelecionado != null) {
            clienteSelecionado.setId(textField_Id.getText());
            clienteSelecionado.setNome(textField_Nome.getText());
            clienteSelecionado.setCpf(textField_CPF.getText());
            clienteSelecionado.setTelefone(textField_Telefone.getText());
            clienteSelecionado.setEndereco(textField_Endereco.getText());
            clienteSelecionado.setNumero(textField_Numero.getText());
            clienteSelecionado.setCidade(textField_Cidade.getText());
            clienteSelecionado.setUf(textField_UF.getText());
            clienteSelecionado.setCep(textField_CEP.getText());
            clienteSelecionado.setDataNascimento(datePicker_Nascimento.getValue() != null ? datePicker_Nascimento.getValue().toString() : "");
            clienteSelecionado.setSexo(combo_sexo.getValue());

            clienteDAO.atualizar(clienteSelecionado); // Atualiza o cliente na base de dados
            tableView_Clientes.refresh(); // Atualiza a tabela
            limparCampos();

            boolean sucessoAoAtualizar = false;
            try {
                // Se a linha acima executar sem erros, consideramos sucesso:
                sucessoAoAtualizar = true;

                System.out.println("Cliente atualizado com sucesso no backend/banco."); // Log para debug

            } catch (Exception e) {
                // Se ocorrer um erro durante a atualização
                e.printStackTrace();
                mostrarAlerta("Erro ao Atualizar", "Ocorreu um erro ao tentar atualizar o cliente: " + e.getMessage(), AlertType.ERROR);
                return; // Interrompe a execução aqui
            }

            if (sucessoAoAtualizar) {
                // MOSTRAR MENSAGEM DE SUCESSO:
                mostrarAlerta("Sucesso", "Cliente atualizado com sucesso!", AlertType.INFORMATION);

            }

        }

    }

    @FXML
    private void excluirCliente() {
        Cliente clienteSelecionado = tableView_Clientes.getSelectionModel().getSelectedItem();

        if (clienteSelecionado == null) {
            mostrarAlerta("Atenção", "Por favor, selecione um cliente na tabela para excluir.", AlertType.WARNING);
            return;
        }

        Alert alertConfirmacao = new Alert(AlertType.CONFIRMATION);
        alertConfirmacao.setTitle("Confirmar Exclusão");
        alertConfirmacao.setHeaderText("Você tem certeza que deseja excluir este cliente?");
        alertConfirmacao.setContentText("Cliente: " + clienteSelecionado.getNome() + " (ID: " + clienteSelecionado.getId() + ")"
                + "\n\nEsta ação não poderá ser desfeita.");

        Optional<ButtonType> resultado = alertConfirmacao.showAndWait();

        if (resultado.isPresent() && resultado.get() == ButtonType.OK) {
            // O usuário clicou em "OK", prosseguir com a exclusão
            try {
                clienteDAO.deletar(clienteSelecionado.getId()); // Exclui o cliente na base de dados

                carregarClientesNaTabela();

                mostrarAlerta("Sucesso", "Cliente excluído com sucesso!", AlertType.INFORMATION);
                limparCampos(); // Limpa os campos do formulário

            } catch (Exception e) {
                e.printStackTrace();
                mostrarAlerta("Erro ao Excluir", "Ocorreu um erro ao tentar excluir o cliente: " + e.getMessage(), AlertType.ERROR);
            }
        } else {
            // O usuário clicou em "Cancelar" ou fechou o diálogo
            System.out.println("Exclusão cancelada pelo usuário.");
        }
    }

    private void carregarClientesNaTabela() {
        try {
            if (listaClientes != null) {
                listaClientes.clear(); // Limpa a lista atual para evitar duplicatas
                listaClientes.addAll(clienteDAO.listarTodos()); // Busca todos os clientes do banco/DAO
                tableView_Clientes.setItems(listaClientes); // Garante que a tabela use a lista
                System.out.println("Clientes carregados do DAO e exibidos na tabela.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            mostrarAlerta("Erro ao Carregar", "Não foi possível carregar a lista de clientes: " + e.getMessage(), AlertType.ERROR);
        }
    }

    @FXML
    private void ProsseguirAgendamento(ActionEvent event) {
        // 1. Obter o cliente selecionado da tabela
        Cliente clienteSelecionado = tableView_Clientes.getSelectionModel().getSelectedItem();

        // Verificar se um cliente foi selecionado
        if (clienteSelecionado == null) {
            mostrarAlerta("Atenção", "Por favor, selecione um cliente na tabela para prosseguir com o agendamento.", Alert.AlertType.WARNING);
            return; // Interrompe se nenhum cliente estiver selecionado
        }

        try {
           
            FXMLLoader loader = new FXMLLoader(Objects.requireNonNull(getClass().getResource("/sistemaodonto/View/Agendamento.fxml")));
            Parent root = loader.load();

            // 2. Obter a instância do AgendamentoController
            AgendamentoController agendamentoController = loader.getController();

            // 3. Passar o cliente selecionado para o AgendamentoController
            agendamentoController.carregarDadosCliente(clienteSelecionado);

            // Obtém o Stage (janela) atual a partir do evento do botão
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // Cria uma nova cena com o FXML carregado
            Scene scene = new Scene(root);

            // Define a nova cena no Stage
            stage.setScene(scene);
            stage.setTitle("Agendamento"); 
            stage.show();

        } catch (IOException e) {
            System.err.println("Erro ao carregar a tela de Agendamento: " + e.getMessage());
            e.printStackTrace();
            mostrarAlerta("Erro de Navegação", "Não foi possível carregar a tela de agendamento: " + e.getMessage(), AlertType.ERROR);
        }
    }

    @FXML
    private void adicionarCliente() {
        // Habilitar campos para entrada de dados
        habilitarCampos();

        // Limpar campos para um novo cliente
        limparCampos();

        // Habilitar os botões Cancelar
        button_Cancelar.setDisable(false);
    }

    private void habilitarCampos() {
        textField_Nome.setDisable(false);
        textField_CPF.setDisable(false);
        textField_Telefone.setDisable(false);
        textField_Endereco.setDisable(false);
        textField_Numero.setDisable(false);
        textField_Cidade.setDisable(false);
        textField_UF.setDisable(false);
        textField_CEP.setDisable(false);
        datePicker_Nascimento.setDisable(false);
        combo_sexo.setDisable(false);
    }

    private void desabilitarCampos() {
        textField_Nome.setDisable(true);
        textField_CPF.setDisable(true);
        textField_Telefone.setDisable(true);
        textField_Endereco.setDisable(true);
        textField_Numero.setDisable(true);
        textField_Cidade.setDisable(true);
        textField_UF.setDisable(true);
        textField_CEP.setDisable(true);
        datePicker_Nascimento.setDisable(true);
        combo_sexo.setDisable(true);
    }

    private void verificarCampos() {
        button_Salvar.setDisable(!camposPreenchidos());
        button_Cancelar.setDisable(!camposPreenchidos());
    }

    private boolean camposPreenchidos() {
        return !textField_Nome.getText().isEmpty()
                && !textField_CPF.getText().isEmpty()
                && !textField_Telefone.getText().isEmpty()
                && datePicker_Nascimento.getValue() != null;
    }

    private void preencherCampos(Cliente cliente) {
        textField_Id.setText(cliente.getId());
        textField_Nome.setText(cliente.getNome());
        textField_CPF.setText(cliente.getCpf());
        textField_Telefone.setText(cliente.getTelefone());
        textField_Endereco.setText(cliente.getEndereco());
        textField_Numero.setText(cliente.getNumero());
        textField_Cidade.setText(cliente.getCidade());
        textField_UF.setText(cliente.getUf());
        textField_CEP.setText(cliente.getCep());
        datePicker_Nascimento.setValue(cliente.getDataNascimento() != null ? LocalDate.parse(cliente.getDataNascimento()) : null);
        combo_sexo.setValue(cliente.getSexo());
    }

    private void limparCampos() {
        textField_Id.clear();
        textField_Nome.clear();
        textField_CPF.clear();
        textField_Telefone.clear();
        textField_Endereco.clear();
        textField_Numero.clear();
        textField_Cidade.clear();
        textField_UF.clear();
        textField_CEP.clear();
        datePicker_Nascimento.setValue(null);
        combo_sexo.getSelectionModel().clearSelection();

        button_Atualizar.setDisable(true);
        button_Excluir.setDisable(true);

    }

    private void mostrarAlerta(String titulo, String mensagem, AlertType tipoAlerta) {
        Alert alert = new Alert(tipoAlerta);
        alert.setTitle(titulo);
        alert.setHeaderText(null); // Pode ser usado para um cabeçalho antes da mensagem principal
        alert.setContentText(mensagem);
        alert.showAndWait(); // Mostra o alerta e espera o usuário fechá-lo
    }

}
