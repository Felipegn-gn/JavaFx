/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package sistemaodonto.model.dao;

import java.util.List;
import sistemaodonto.model.Cliente;

/**
 *
 * @author Laboratorio
 */
public interface ClienteDAO {
 
    void salvar(Cliente cliente);
    void atualizar(Cliente cliente);
    void deletar(String id);
    Cliente buscarPorCpf(String id);
    List<Cliente> listarTodos();
    
}
